package semantic

import (
	"reflect"

	"elisacore/src/ast"
)

// containerGrowthMethods are the by-reference container operations that ALLOCATE into the
// container's backing region. A call to one of these on a parameter is what forces that
// parameter to carry a region: the push site needs an ambient arena, and across a function
// boundary the only one available is the caller's, threaded in. Read-only operations
// (`.count`, indexing, iteration) never need it, so a darray& param used purely for reading
// is deliberately NOT made region-polymorphic.
var containerGrowthMethods = map[string]bool{
	"push":    true,
	"extend":  true,
	"insert":  true,
	"resize":  true,
	"reserve": true,
	"append":  true,
	"put":     true, // dict
	"add":     true, // set
}

// inferRegionParamsForGrownContainerParams is the docs/75 S2 callee-side inference for
// cross-function lifetime. A function that GROWS a region-less by-reference container parameter
// — `def fill(out: mutable darray[T]&): out.push(...)` — is rewritten in place into the explicit
// region-parameter form `def fill[@__rg_out](out: mutable darray[T]& @__rg_out): ...`,
// so the rest of the pipeline sees exactly the (proven sound, S1) annotated shape: the
// caller's region arena is threaded as a hidden Arena& and resolves the growth allocator, and
// resolveType's region push-down unifies `@__rg_out` through the ref onto the container so it
// binds against the `&v` argument's region.
//
// This MUST run BEFORE collectValueSymbols so the synthesized region params and the stamped
// param `@r` are baked into the FuncType at construction time (RegionParams + the param's
// resolved container Region), keeping the AST and the type in lockstep without a second mutation.
//
// SAFETY: this adds no new lifetime power — it only spells, automatically, the `[@r]`/`@r`
// a user could write by hand (and which S1 proved sound under ASan). The "what is stored INTO
// the grown param" lifetime obligation stays guarded by the existing escape checker
// (checkNestedRegionStoreEscape et al.); inference only decides where the param's own backing
// arena comes from.
func (a *Analyzer) inferRegionParamsForGrownContainerParams(decls []scopedDecl) {
	cands := collectRegionPolyCandidateFuncs(decls)
	// This pass runs before collectValueSymbols, so funcDeclUsings has not been
	// populated yet. Keep the lexical resolution context alongside the function
	// declarations: the region-valued argument probe below may need to resolve a
	// callee's return annotation, and doing that in the caller's ambient context
	// makes a perfectly valid unqualified module-local type look unknown.
	funcScopes := map[*ast.FuncDecl]scopedDecl{}
	for _, scoped := range decls {
		switch n := scoped.Decl.(type) {
		case *ast.FuncDecl:
			funcScopes[n] = scoped
		case *ast.ImplDecl:
			for _, member := range n.Members {
				if fn, ok := member.(*ast.FuncDecl); ok {
					funcScopes[fn] = scoped
				}
			}
		}
	}
	// Resolve direct free-function call targets by name for the forwarding trigger. Overloads/last-wins
	// is acceptable: a wrong match only forgoes (or, at worst, conservatively adds) an inferred region
	// param — soundness is unaffected (the region threading is still verified at the real call site).
	// Program-lifetime region roots: a container growth lexically inside `in perm:` or
	// `in &<global>:` (a global/extern var arena) already has a program-lifetime allocation
	// region supplied — its backing outlives every possible caller storage, so the param needs
	// NO threaded region (and forcing one rejects the idiomatic helper that grows a caller-owned
	// container into a global perm arena). Scoped arenas (`region r:`, `with arena ... as s`)
	// are NOT here: their backing dies at scope exit, so growth into them must still thread (or
	// be rejected as a dangling write).
	permRoots := collectProgramLifetimeRoots(decls)
	funcByName := map[string]*ast.FuncDecl{}
	explicit := map[*ast.FuncDecl]bool{}
	for _, fn := range cands {
		if fn == nil {
			continue
		}
		funcByName[fn.Name] = fn
		// Functions that already manage regions explicitly are left alone: a hand-written `[@r]` owns
		// the threading, and an `Arena&` param self-threads its allocator.
		if len(fn.RegionParams) != 0 || funcHasArenaParam(fn) {
			explicit[fn] = true
		}
	}
	// Fixpoint: making one function region-polymorphic turns it into a region-REQUIRING callee, so a
	// caller that merely FORWARDS a container/struct ref param to it must itself become region-poly to
	// thread the region through. Iterate until no function gains a new region param. Each per-function
	// pass is idempotent (an already-stamped param's type carries its region, so it no longer matches
	// the region-LESS predicates), so reprocessing only ever picks up newly-enabled params.
	for {
		changed := false
		for _, fn := range cands {
			if fn == nil || explicit[fn] {
				continue
			}
			if a.inferRegionParamsForGrownContainerParamsIn(fn, funcByName, permRoots, funcScopes) {
				changed = true
			}
		}
		if !changed {
			break
		}
	}
}

func (a *Analyzer) inferRegionParamsForGrownContainerParamsIn(fn *ast.FuncDecl, funcByName map[string]*ast.FuncDecl, permRoots map[string]bool, funcScopes map[*ast.FuncDecl]scopedDecl) bool {
	if fn == nil || len(fn.Body) == 0 {
		return false
	}
	changed := false
	inferred := map[string]string{} // param name -> inferred region-param name
	// ambientGrownParam is the container param (if any) grown by INSERTING region-allocated values
	// (the void-grower shape). Its inferred region becomes the function's ambient allocation region so
	// the inserted value's region-poly producer allocates into the caller's container region.
	ambientGrownParam := ""
	// Count regionless-ref-container params: the ambient-region binding is only SOUND when there is
	// exactly one. With two (`def bad(scratch: darray&, keep: darray&)`), binding the ambient region to
	// one container lets a value inserted into it ALSO be inserted into the other (a different-lifetime)
	// container — an escape the handle-level checker does not yet catch. Restricting to a single
	// container param removes that second target entirely (and covers every parser grower, all single
	// `out`). Other escape vectors (explicit inner regions, returns) remain covered by existing checks.
	containerParamCount := 0
	for i := range fn.Params {
		if _, ok := regionlessRefContainer(fn.Params[i].Type); ok {
			containerParamCount++
		}
	}
	for i := range fn.Params {
		p := &fn.Params[i]
		var stamp func(string)
		if cstamp, ok := regionlessRefContainer(p.Type); ok {
			// A grown / literal-reassigned container ref param, OR one merely FORWARDED to a callee that
			// requires a region there (so the region must thread through this function too).
			grownWithRegionValue := a.containerParamGrownWithRegionValue(fn, p.Name, funcByName, funcScopes)
			if paramContainerIsGrownNeedingRegion(fn.Body, p.Name, permRoots) || paramContainerReassignedFromLiteral(fn.Body, p.Name) || a.paramForwardedToRegionRequiringCallee(fn.Body, p.Name, funcByName) || grownWithRegionValue {
				stamp = cstamp
				if grownWithRegionValue && ambientGrownParam == "" && containerParamCount == 1 {
					ambientGrownParam = p.Name
				}
			}
		} else if sstamp, ok := regionlessRefStruct(p.Type); ok {
			// docs/91 S4 Stage 1: a region-less by-ref STRUCT param whose CONTAINER FIELD is grown
			// (`def fill(m: mutable Mod&): m.bits.push(..)`), or which is forwarded to a region-
			// requiring callee. Stamp the inferred region onto the struct ref (`Mod& @r`): the
			// field-region propagation pushes it onto the resolved field container, and the same
			// return-escape checks that guard the explicit `[@r]` form cover every borrow-out vector
			// regardless of how the region param was introduced — no new lifetime power.
			if paramFieldContainerIsGrown(fn.Body, p.Name) || a.paramForwardedToRegionRequiringCallee(fn.Body, p.Name, funcByName) {
				stamp = sstamp
			}
		}
		if stamp == nil {
			continue
		}
		// Param names are unique within a function, so the per-param suffix yields a unique,
		// deterministic region-param name (no Date/random — must stay resume-stable).
		name := "__rg_" + p.Name
		stamp(name)
		fn.RegionParams = append(fn.RegionParams, name)
		inferred[p.Name] = name
		changed = true
	}
	if len(inferred) > 0 {
		inferReturnViewRegion(fn, inferred)
	}
	// Record the ambient grown-container region on the FuncType so the backend binds this function's
	// ambient allocation region to it (the void-grower fix): inserted region-poly values then land in
	// the caller-owned container's region instead of a per-call arena freed on return.
	if ambientGrownParam != "" {
		// Recorded on the AST FuncDecl (like RegionParams) — symbol/FuncType resolution is not reliably
		// available at this pre-pass, and the backend reads the FuncDecl directly.
		fn.AmbientGrownContainerRegion = "__rg_" + ambientGrownParam
		// Callers' stack assignment must know which arg position feeds the ambient region: a
		// container forwarded here gets adopted payload allocations interleaved into its arena,
		// so its stack cannot be tail-only reserve_commit (see assignRegionStacks).
		if a.ambientGrownCalleeParamIndex != nil {
			for i := range fn.Params {
				if fn.Params[i].Name == ambientGrownParam {
					a.ambientGrownCalleeParamIndex[fn.Name] = i
					break
				}
			}
		}
	}
	return changed
}

// paramForwardedToRegionRequiringCallee reports whether the body passes the named parameter (as a bare
// identifier, `&param`, or a reborrow cast) as an argument to a resolved direct free-function/UFCS call
// whose parameter at that position REQUIRES a region (its type carries one of the callee's region
// params). Such a forward makes this function region-polymorphic over the param even though it never
// grows it itself — the callee's region must be threaded in. Conservative: an unresolved/indirect
// callee, or a non-region-requiring position, simply doesn't trigger (a false negative re-surfaces
// as the existing "cannot infer region parameter" error, never an unsound accept).
//
// IMPORTANT: a PascalCase callee `Name(args)` parses as an *ast.StructLitExpr (constructor-or-call
// ambiguity) at this pre-pass — name resolution only reclassifies it to a call later. So a free call
// to a region-requiring function with an uppercase name (the bulk of the loader's call graph) is a
// StructLitExpr here, not a CallExpr; both forms are handled below.
func (a *Analyzer) paramForwardedToRegionRequiringCallee(stmts []ast.Stmt, name string, funcByName map[string]*ast.FuncDecl) bool {
	found := false
	// checkCall tests whether passing `name` at some position of a call to `calleeName(args)` lands in a
	// region-requiring callee parameter.
	checkCall := func(calleeName string, args []ast.Expr) bool {
		callee := funcByName[calleeName]
		if callee == nil {
			return false
		}
		params := a.expandedFuncDeclParams(callee)
		rps := map[string]bool{}
		for _, rp := range callee.RegionParams {
			rps[rp] = true
		}
		if len(rps) == 0 {
			return false
		}
		for argPos, arg := range args {
			if forwardsParamIdent(arg, name) && argPos < len(params) && typeExprCarriesRegionParam(params[argPos].Type, rps) {
				return true
			}
		}
		return false
	}
	var rec func(v reflect.Value)
	rec = func(v reflect.Value) {
		if found || !v.IsValid() || !v.CanInterface() {
			return
		}
		switch v.Kind() {
		case reflect.Pointer:
			if v.IsNil() {
				return
			}
			if expr, ok := v.Interface().(ast.Expr); ok {
				calleeName, args, isCall := ast.PrepassCallShape(expr)
				if isCall && checkCall(calleeName, args) {
					found = true
					return
				}
			}
			rec(v.Elem())
		case reflect.Interface:
			if v.IsNil() {
				return
			}
			rec(v.Elem())
		case reflect.Struct:
			for i := 0; i < v.NumField(); i++ {
				rec(v.Field(i))
			}
		case reflect.Slice, reflect.Array:
			for i := 0; i < v.Len(); i++ {
				rec(v.Index(i))
			}
		}
	}
	rec(reflect.ValueOf(stmts))
	return found
}

// forwardsParamIdent reports whether an argument expression passes the parameter `name` through: a bare
// identifier, `&name` (address-of), or a reborrow reinterpret cast `(&name).cast[T&]` — peeling parens,
// address-of, and casts (S4 Stage 3: the loader's pervasive `(&self).cast[mutable T&]` reborrow idiom).
// This only decides region-poly inference; the region is still verified at the real call site (where
// the cast now preserves the operand's region), so seeing through the cast here is sound.
func forwardsParamIdent(arg ast.Expr, name string) bool {
	for {
		switch e := unwrapParenForRegionPoly(arg).(type) {
		case *ast.Ident:
			return e != nil && e.Name == name
		case *ast.AddrOfExpr:
			if e == nil {
				return false
			}
			arg = e.Operand
		case *ast.CastExpr:
			if e == nil {
				return false
			}
			arg = e.Operand
		default:
			return false
		}
	}
}

// typeExprCarriesRegionParam reports whether a parameter type-expr is annotated with a region that is
// one of the callee's region params (so passing a value there REQUIRES supplying that region). Peels
// the mutable/owned/tail/ref qualifiers and checks the region annotation on the reference, the
// container builtin, or a generic type.
func typeExprCarriesRegionParam(t ast.TypeExpr, regionParams map[string]bool) bool {
	for t != nil {
		switch n := t.(type) {
		case *ast.MutableType:
			t = n.Elem
		case *ast.OwnedType:
			t = n.Elem
		case *ast.TailType:
			t = n.Elem
		case *ast.RefType:
			if n.Region != "" && regionParams[n.Region] {
				return true
			}
			t = n.Elem
		case *ast.BuiltinTypeExpr:
			return n.Region != "" && regionParams[n.Region]
		case *ast.GenericType:
			return n.Region != "" && regionParams[n.Region]
		default:
			return false
		}
	}
	return false
}

// inferReturnViewRegion ties a function's region-less `view[T]` return type to an inferred region
// param when the body provably returns a slice (`param[a:b]`) of that param's container — `def
// head(out: mutable darray[u8]&, n) -> view[u8]: out.push(..); return out[0:n]`. Without this the
// returned view is region-less, so a caller storing it past the source region's death is not caught
// (a use-after-free — the same hole the explicit `-> view[u8] @r` form now closes). Stamping the
// return type's region makes the call-site substitution resolve it to the caller's region, where the
// existing escape checker proves the borrow cannot outlive its backing.
//
// Tightly scoped for soundness: only when EXACTLY ONE region param was inferred (so the source
// region is unambiguous), the declared return type is a region-less view, and a `return param[...]`
// over the matching grown param is present. A returned view into a dying LOCAL is already rejected
// upstream, so a function reaching here with a compiling body returns a view backed by the param's
// (caller-provided) region — exactly the region we stamp.
func inferReturnViewRegion(fn *ast.FuncDecl, inferred map[string]string) {
	if len(inferred) != 1 {
		return
	}
	view, ok := fn.ReturnType.(*ast.BuiltinTypeExpr)
	if !ok || view.Name != "view" || view.Region != "" {
		return
	}
	for paramName, regionName := range inferred {
		if functionReturnsSliceOfParam(fn.Body, paramName) {
			view.Region = regionName
		}
	}
}

// functionReturnsSliceOfParam reports whether the body returns a slice whose object is the named
// parameter as a bare identifier, either directly (`return param[a:b]`) or through simple local
// aliases (`w = param[a:b]; return w`). Conservative: a false negative just leaves the return
// region-less (the pre-existing, safe-but-unchecked state), never the reverse.
func functionReturnsSliceOfParam(stmts []ast.Stmt, name string) bool {
	// SOUNDNESS: a local that is EVER aliased to the grown param's slice (on any path) is treated as
	// param-backed when returned, so the region stamp is applied and the escape checker can reject a
	// dangling return. We deliberately do NOT invalidate the alias on a later reassignment: doing so
	// flow-insensitively (a conditional `if c: w <- other`) would drop the stamp on the path that
	// still returns the param-backed view — a use-after-free hole (a regression that was caught at
	// runtime). Over-stamping only over-rejects (e.g. `w = param[a:b]; w <- other; return w`, where w
	// is always rebound), which is sound; precise flow-sensitive invalidation is a future refinement.
	aliases := map[string]bool{}
	valueIsParamSlice := func(expr ast.Expr) bool {
		if slice, ok := unwrapParenForRegionPoly(expr).(*ast.SliceExpr); ok && slice != nil {
			if id, ok := unwrapParenForRegionPoly(slice.Object).(*ast.Ident); ok && id != nil && id.Name == name {
				return true
			}
		}
		if id, ok := unwrapParenForRegionPoly(expr).(*ast.Ident); ok && id != nil && aliases[id.Name] {
			return true
		}
		return false
	}
	var collect func([]ast.Stmt)
	collect = func(body []ast.Stmt) {
		for _, stmt := range body {
			switch s := stmt.(type) {
			case *ast.VarDeclStmt:
				if s.Value != nil && valueIsParamSlice(s.Value) {
					aliases[s.Name] = true
				}
			case *ast.AssignStmt:
				if id, ok := s.Target.(*ast.Ident); ok && id != nil && s.Value != nil && valueIsParamSlice(s.Value) {
					aliases[id.Name] = true
				}
			case *ast.IfStmt:
				collect(s.Then)
				for _, elif := range s.Elifs {
					collect(elif.Body)
				}
				collect(s.Else)
			case *ast.WhileStmt:
				collect(s.Body)
			case *ast.ForStmt:
				collect(s.Body)
			case *ast.IterForStmt:
				collect(s.Body)
			case *ast.ScopeStmt:
				collect(s.Body)
			case *ast.CanStmt:
				collect(s.Body)
			case *ast.RegionStmt:
				collect(s.Body)
			case *ast.InStoreStmt:
				collect(s.Body)
			case *ast.MatchStmt:
				for _, arm := range s.Arms {
					collect(arm.Body)
				}
			}
		}
	}
	for {
		before := len(aliases)
		collect(stmts)
		if len(aliases) == before {
			break
		}
	}

	found := false
	var rec func(v reflect.Value)
	rec = func(v reflect.Value) {
		if found || !v.IsValid() || !v.CanInterface() {
			return
		}
		switch v.Kind() {
		case reflect.Pointer:
			if v.IsNil() {
				return
			}
			if ret, ok := v.Interface().(*ast.ReturnStmt); ok && ret != nil {
				if valueIsParamSlice(ret.Value) {
					found = true
					return
				}
			}
			rec(v.Elem())
		case reflect.Interface:
			if v.IsNil() {
				return
			}
			rec(v.Elem())
		case reflect.Struct:
			for i := 0; i < v.NumField(); i++ {
				rec(v.Field(i))
			}
		case reflect.Slice, reflect.Array:
			for i := 0; i < v.Len(); i++ {
				rec(v.Index(i))
			}
		}
	}
	rec(reflect.ValueOf(stmts))
	return found
}

// regionlessRefContainer reports whether a parameter type is a by-reference (`&`) region-less
// growable container, and if so returns a closure that stamps a region name onto the right AST node.
// Two container spellings qualify:
//   - `darray`/`dict`/`set` — a *ast.BuiltinTypeExpr; the region is stamped onto its `.Region`.
//   - `dstr` — a *ast.NamedType (the u8-darray string; it has no `@r` annotation surface, so it
//     can't carry a region itself). The region is stamped onto the enclosing *ast.RefType instead,
//     which resolveType then pushes DOWN onto the resolved DArrayType via stampContainerRegion —
//     the identical normalization the builtin path relies on, so both spellings produce the same
//     resolved region-carrying container type.
//
// The `&` is required: only a reference makes the callee's growth (header realloc + count) visible
// in the caller — a by-value container param copies the header, so growth would be lost (the S1
// footgun). An existing `@r` anywhere (on the ref or the container) means the user is already
// managing the region: leave it alone.
func regionlessRefContainer(typ ast.TypeExpr) (func(region string), bool) {
	var ref *ast.RefType
	for {
		switch t := typ.(type) {
		case *ast.MutableType:
			typ = t.Elem
		case *ast.OwnedType:
			typ = t.Elem
		case *ast.RefType:
			if t.Region != "" {
				return nil, false
			}
			ref = t
			typ = t.Elem
		case *ast.BuiltinTypeExpr:
			if ref == nil || t.Region != "" {
				return nil, false
			}
			switch t.Name {
			case "darray", "dict", "set":
				return func(region string) { t.Region = region }, true
			}
			return nil, false
		case *ast.NamedType:
			if ref == nil || t.Name != "dstr" {
				return nil, false
			}
			// dstr has no region surface of its own; stamp the ref, which resolveType
			// pushes down onto the resolved DArrayType.
			r := ref
			return func(region string) { r.Region = region }, true
		default:
			return nil, false
		}
	}
}

// regionlessRefStruct reports whether a parameter type is a by-reference (`&`) region-less STRUCT
// (a *ast.NamedType that is NOT a region-carrying container — those go through regionlessRefContainer),
// and if so returns a closure that stamps a region name onto the enclosing *ast.RefType. A struct
// has no `@r` surface of its own; the region rides on the ref, and the field-region propagation in
// analyzeFieldExpr (plus the backend's containerRegionName reading RefType.Region for struct refs)
// pushes it onto the resolved container field — the same normalization the dstr path relies on.
//
// The `&` is required for the same reason as containers: only a reference makes the callee's field
// growth (header realloc + count) visible in the caller. An existing `@r` on the ref means the user
// already manages the region: leave it alone (Stage 0's explicit form).
func regionlessRefStruct(typ ast.TypeExpr) (func(region string), bool) {
	var ref *ast.RefType
	for {
		switch t := typ.(type) {
		case *ast.MutableType:
			typ = t.Elem
		case *ast.OwnedType:
			typ = t.Elem
		case *ast.RefType:
			if t.Region != "" {
				return nil, false
			}
			ref = t
			typ = t.Elem
		case *ast.NamedType:
			if ref == nil || t.Name == "dstr" {
				return nil, false
			}
			r := ref
			return func(region string) { r.Region = region }, true
		default:
			return nil, false
		}
	}
}

// refParamIsPackedEnum reports whether a parameter type is a by-reference (`&`) region-backed PACKED
// enum (a handle-tree node type like `Ast::Expr`) with no explicit region already on the ref. Peels the
// mutable/owned/ref qualifiers, resolves the referent, and checks it is a packed EnumType (or a packed
// enum root). Used to restrict the scalar-out-param region-thread to the handle-enum UAF class — an
// ordinary struct out-param (no region-backed storage) is left to the existing field-grown/forwarded
// triggers. Conservative: an unresolved/non-enum type returns false (no thread, prior behavior).
func (a *Analyzer) refParamIsPackedEnum(typ ast.TypeExpr) bool {
	var ref *ast.RefType
	for {
		switch t := typ.(type) {
		case *ast.MutableType:
			typ = t.Elem
		case *ast.OwnedType:
			typ = t.Elem
		case *ast.RefType:
			if t.Region != "" {
				return false
			}
			ref = t
			typ = t.Elem
		default:
			if ref == nil {
				return false
			}
			// Resolve under diagnostic suppression: this runs at the pre-body classification pass where a
			// generic type-param name (`T`/`K` from an enclosing `extend[T]`) is not yet in scope, so a
			// bare resolveType would emit a spurious "unknown type" error. We only need the boolean.
			savedSuppress := a.suppressDiagnostics
			a.suppressDiagnostics = true
			resolved := a.resolveType(typ)
			a.suppressDiagnostics = savedSuppress
			et, ok := resolved.(*EnumType)
			return ok && et != nil && (et.Packed || et.Root().Packed)
		}
	}
}

// paramFieldContainerIsGrown reports whether the body contains a growth-method call whose receiver is
// a FIELD of the named struct parameter — `param.field.push(...)`. Mirrors paramContainerIsGrown but
// peels one field access (the container lives inside the struct). A false negative only forgoes the
// ergonomic rewrite (the old "active region" error still fires, which is safe); a false positive only
// threads an unused region param.
func paramFieldContainerIsGrown(stmts []ast.Stmt, name string) bool {
	found := false
	var rec func(v reflect.Value)
	rec = func(v reflect.Value) {
		if found || !v.IsValid() || !v.CanInterface() {
			return
		}
		switch v.Kind() {
		case reflect.Pointer:
			if v.IsNil() {
				return
			}
			// A growth nested inside an explicit `in <arena>:` (InStoreStmt) or USER-written
			// local `region:` (RegionStmt) scope already has its allocation region supplied
			// lexically — no region param threading is needed (and forcing `@r` would make the
			// call site demand a region the struct ref doesn't carry). Don't descend into those.
			// BUT a compiler-SYNTHESIZED `__auto_*` region (the parser's speculative
			// maybeWrapFunctionBodyInAutoRegion wrap, e.g. when the body forwards a constructed
			// struct-literal element to a push) is NOT a real allocation region for the param's
			// field: growing a by-ref struct param's field into a per-call auto arena that frees
			// on return is a use-after-free. We MUST see through such a wrap so the field growth
			// stamps `@r` and threads the caller's region. Descend into synthesized regions only.
			switch s := v.Interface().(type) {
			case *ast.InStoreStmt:
				return
			case *ast.RegionStmt:
				if !isSynthesizedAutoRegion(s.Name) {
					return
				}
				// fall through to descend into the synthesized wrap's body
			}
			if call, ok := v.Interface().(*ast.CallExpr); ok {
				if growth, ok := call.Func.(*ast.FieldExpr); ok && growth != nil && containerGrowthMethods[growth.Field] {
					// Receiver must be a FIELD/INDEX PATH rooted at the param — `param.f.push(..)`,
					// `param.a.b.push(..)` (any depth), `param.f[i].push(..)`. A path deeper than the
					// bare param means the grown container is a (possibly nested) field of the struct
					// param, so the param carries the region the field backing grows into. (The bare-param
					// case `param.push` is a CONTAINER param, handled by paramContainerIsGrown.)
					if _, isPath := growth.Object.(*ast.FieldExpr); isPath {
						if root := rootIdentExpr(growth.Object); root != nil && root.Name == name {
							found = true
							return
						}
					}
				}
			}
			rec(v.Elem())
		case reflect.Interface:
			if v.IsNil() {
				return
			}
			rec(v.Elem())
		case reflect.Struct:
			for i := 0; i < v.NumField(); i++ {
				rec(v.Field(i))
			}
		case reflect.Slice, reflect.Array:
			for i := 0; i < v.Len(); i++ {
				rec(v.Index(i))
			}
		}
	}
	rec(reflect.ValueOf(stmts))
	return found
}

// paramContainerIsGrown reports whether the body contains a growth-method call (push/extend/…)
// whose receiver is the named parameter — `param.push(...)`. A false negative only forgoes the
// ergonomic rewrite (the old "requires an active in <arena>: scope" error still fires, which is
// safe); a false positive only threads an unused region param. Scans structurally via reflection,
// mirroring bodyCallsStoreNeedingOutsideRegion.
func paramContainerIsGrown(stmts []ast.Stmt, name string) bool {
	found := false
	var rec func(v reflect.Value)
	rec = func(v reflect.Value) {
		if found || !v.IsValid() || !v.CanInterface() {
			return
		}
		switch v.Kind() {
		case reflect.Pointer:
			if v.IsNil() {
				return
			}
			if call, ok := v.Interface().(*ast.CallExpr); ok {
				if field, ok := call.Func.(*ast.FieldExpr); ok && field != nil && containerGrowthMethods[field.Field] {
					if id, ok := field.Object.(*ast.Ident); ok && id != nil && id.Name == name {
						found = true
						return
					}
				}
			}
			rec(v.Elem())
		case reflect.Interface:
			if v.IsNil() {
				return
			}
			rec(v.Elem())
		case reflect.Struct:
			for i := 0; i < v.NumField(); i++ {
				rec(v.Field(i))
			}
		case reflect.Slice, reflect.Array:
			for i := 0; i < v.Len(); i++ {
				rec(v.Index(i))
			}
		}
	}
	rec(reflect.ValueOf(stmts))
	return found
}

// containerParamGrownWithRegionValue reports whether the body grows the named container parameter
// (`name.push(v)` / .extend / .insert / …) with a value whose RESOLVED TYPE carries region-backed
// storage — a packed-enum node or a nested container. Such an insert moves a region-allocated value
// into a CALLER-OWNED container, so the value's backing must live in the param's region or it dangles
// when this function returns (the void-grower use-after-free: a region-poly callee's payload darray is
// pushed into `out` but lands in a grower-local region freed on return). Stamping `__rg_<param>` makes
// the param's region threadable; the backend then binds the grower's ambient allocation region to it so
// the inserted value's region-poly producer allocates into the param's region (and is adopted with it).
//
// PRE-CLASSIFICATION-SAFE: decides purely from RESOLVED TYPES (callee return types, local binding
// types, packed-enum constructors), NEVER region-poly classification — which runs after this pass
// (analyzer.go: inferRegionParamsForGrownContainerParams precedes classifyRegionPolymorphicFunctions).
// Traces an inserted ident through its var-decl / assignment / `if EXPR is x` refinement binding to its
// producing expression. Conservative both ways: an unresolved insert simply doesn't trigger (the prior
// behavior, sound), and over-triggering only threads a region the caller — which owns the container —
// can always supply.
func (a *Analyzer) containerParamGrownWithRegionValue(fn *ast.FuncDecl, name string, funcByName map[string]*ast.FuncDecl, funcScopes map[*ast.FuncDecl]scopedDecl) bool {
	if fn == nil {
		return false
	}
	argIsRegionValued := a.regionValueTester(fn, funcByName, funcScopes)

	// Scan for `name.<growth>(ARG…)` where any inserted ARG is region-valued.
	found := false
	var scan func(v reflect.Value)
	scan = func(v reflect.Value) {
		if found || !v.IsValid() || !v.CanInterface() {
			return
		}
		switch v.Kind() {
		case reflect.Pointer:
			if v.IsNil() {
				return
			}
			if call, ok := v.Interface().(*ast.CallExpr); ok && call != nil {
				if field, ok := call.Func.(*ast.FieldExpr); ok && field != nil && containerGrowthMethods[field.Field] {
					if id, ok := field.Object.(*ast.Ident); ok && id != nil && id.Name == name {
						for _, arg := range call.Args {
							if argIsRegionValued(arg) {
								found = true
								return
							}
						}
					}
				}
			}
			scan(v.Elem())
		case reflect.Interface:
			if v.IsNil() {
				return
			}
			scan(v.Elem())
		case reflect.Struct:
			for i := 0; i < v.NumField(); i++ {
				scan(v.Field(i))
			}
		case reflect.Slice, reflect.Array:
			for i := 0; i < v.Len(); i++ {
				scan(v.Index(i))
			}
		}
	}
	scan(reflect.ValueOf(fn.Body))
	return found
}

// functionWritesHandleToScalarOutParam reports whether the function assigns to a by-reference PACKED
// handle-enum out-param (`def h(out: mutable Ast::Expr&): out <- (Ast::Expr.Foo(...))`). Any value
// assigned to such a ref IS a region-backed handle (the param type is the region-value gate), so if the
// assigned node was BUILT in this function it lives in the per-call arena and frees on return — a UAF
// once the caller stores the handle in a longer-lived node (the docs/125 quantifier `where`-clause bug).
// Detecting this shape classifies the function region-polymorphic (classifyRegionPolymorphicFunctions),
// so it threads `__region_auto` — its node builders then allocate into the CALLER's tree store, exactly
// as a function that RETURNS the node already does. Over-triggering is sound: if the assigned handle was
// built in the caller (already caller-region), the threaded region is simply unused for it. MUST run
// inside the candidate's resolution context so the qualified enum type resolves.
func (a *Analyzer) functionWritesHandleToScalarOutParam(fn *ast.FuncDecl) bool {
	if fn == nil {
		return false
	}
	assignsTo := func(name string) bool {
		found := false
		var scan func(v reflect.Value)
		scan = func(v reflect.Value) {
			if found || !v.IsValid() || !v.CanInterface() {
				return
			}
			switch v.Kind() {
			case reflect.Pointer:
				if v.IsNil() {
					return
				}
				if asn, ok := v.Interface().(*ast.AssignStmt); ok && asn != nil {
					if id, ok := asn.Target.(*ast.Ident); ok && id != nil && id.Name == name {
						found = true
						return
					}
				}
				scan(v.Elem())
			case reflect.Interface:
				if v.IsNil() {
					return
				}
				scan(v.Elem())
			case reflect.Struct:
				for i := 0; i < v.NumField(); i++ {
					scan(v.Field(i))
				}
			case reflect.Slice, reflect.Array:
				for i := 0; i < v.Len(); i++ {
					scan(v.Index(i))
				}
			}
		}
		scan(reflect.ValueOf(fn.Body))
		return found
	}
	for i := range fn.Params {
		p := &fn.Params[i]
		if a.refParamIsPackedEnum(p.Type) && assignsTo(p.Name) {
			return true
		}
	}
	return false
}

// regionValueTester builds the shared "does this expression produce a region-carrying value?" predicate
// used by both containerParamGrownWithRegionValue (inserted args) and scalarRefAssignedRegionValue
// (assigned out-param RHS). It first maps each local name to its producing expression (var-decl,
// assignment, or `if EXPR is x:` refinement binding) so an ident argument resolves to its producer, then
// returns a tester that classifies from RESOLVED TYPES only (callee return types, packed-enum
// constructors, owned-less list literals/comprehensions) — never region-poly classification, which runs
// after this pass. Conservative both ways: an unresolved value simply returns false.
func (a *Analyzer) regionValueTester(fn *ast.FuncDecl, funcByName map[string]*ast.FuncDecl, funcScopes map[*ast.FuncDecl]scopedDecl) func(ast.Expr) bool {
	// 1. Map each local name to the expression it was bound from, so an inserted ident resolves to its
	//    producer: a var-decl value, an assignment, or an `if EXPR is x:` refinement scrutinee.
	boundExpr := map[string]ast.Expr{}
	bind := func(n string, e ast.Expr) {
		if n == "" || e == nil {
			return
		}
		if _, seen := boundExpr[n]; !seen {
			boundExpr[n] = e
		}
	}
	bindRefinements := func(cond ast.Expr) {
		var walk func(v reflect.Value)
		walk = func(v reflect.Value) {
			if !v.IsValid() || !v.CanInterface() {
				return
			}
			switch v.Kind() {
			case reflect.Pointer:
				if v.IsNil() {
					return
				}
				if ob, ok := v.Interface().(*ast.OptionalBindExpr); ok && ob != nil {
					bind(ob.Name, ob.Value)
				}
				walk(v.Elem())
			case reflect.Interface:
				if v.IsNil() {
					return
				}
				walk(v.Elem())
			case reflect.Struct:
				for i := 0; i < v.NumField(); i++ {
					walk(v.Field(i))
				}
			case reflect.Slice, reflect.Array:
				for i := 0; i < v.Len(); i++ {
					walk(v.Index(i))
				}
			}
		}
		walk(reflect.ValueOf(cond))
	}
	var collectBindings func(stmts []ast.Stmt)
	collectBindings = func(stmts []ast.Stmt) {
		for _, stmt := range stmts {
			switch s := stmt.(type) {
			case *ast.VarDeclStmt:
				bind(s.Name, s.Value)
			case *ast.AssignStmt:
				if id, ok := s.Target.(*ast.Ident); ok && id != nil {
					bind(id.Name, s.Value)
				}
			case *ast.IfStmt:
				bindRefinements(s.Cond)
				collectBindings(s.Then)
				for _, elif := range s.Elifs {
					bindRefinements(elif.Cond)
					collectBindings(elif.Body)
				}
				collectBindings(s.Else)
			case *ast.WhileStmt:
				bindRefinements(s.Cond)
				collectBindings(s.Body)
			case *ast.ForStmt:
				collectBindings(s.Body)
			case *ast.IterForStmt:
				collectBindings(s.Body)
			case *ast.MatchStmt:
				for _, arm := range s.Arms {
					collectBindings(arm.Body)
				}
			case *ast.ScopeStmt:
				collectBindings(s.Body)
			case *ast.CanStmt:
				collectBindings(s.Body)
			case *ast.RegionStmt:
				collectBindings(s.Body)
			case *ast.InStoreStmt:
				collectBindings(s.Body)
			}
		}
	}
	collectBindings(fn.Body)
	resolveCalleeReturnType := func(callee *ast.FuncDecl) Type {
		if callee == nil || callee.ReturnType == nil {
			return invalidType
		}
		resolve := func() Type {
			// This is a conservative pre-classification probe. A malformed or
			// not-yet-bound generic return type must not emit a second diagnostic;
			// body analysis reports the authoritative error later.
			savedSuppress := a.suppressDiagnostics
			a.suppressDiagnostics = true
			resolved := a.resolveType(callee.ReturnType)
			a.suppressDiagnostics = savedSuppress
			return resolved
		}
		if scoped, ok := funcScopes[callee]; ok {
			var resolved Type
			a.withResolutionContext(scoped.Namespace, scoped.Usings, func() {
				resolved = resolve()
			})
			return resolved
		}
		return resolve()
	}

	// 2. Decide whether an expression produces a region-carrying value (resolved types only).
	argIsRegionValued := func(arg ast.Expr) bool {
		visited := map[string]bool{}
		var rec func(e ast.Expr, depth int) bool
		rec = func(e ast.Expr, depth int) bool {
			if e == nil || depth > 16 {
				return false
			}
			switch n := unwrapParenForRegionPoly(e).(type) {
			case *ast.AllocExpr:
				return true
			case *ast.ListLitExpr:
				return n != nil && n.Owner == nil
			case *ast.ListComprehensionExpr:
				return n != nil && n.Owner == nil
			case *ast.Ident:
				if n == nil || visited[n.Name] {
					return false
				}
				visited[n.Name] = true
				if prod, ok := boundExpr[n.Name]; ok {
					return rec(prod, depth+1)
				}
				return false
			case *ast.CallExpr:
				// A bare constructor of a region-backed packed enum allocates region storage.
				if et, _, ok := a.packedAllocConstructorInfo(n); ok && et != nil {
					if et.Packed {
						return true
					}
					// An INLINE value-enum constructor (`Item.Row(make_vals(10))`) is region-valued
					// when any payload argument is — the variant embeds the payload directly, so the
					// wrapped container's backing must live in the grown param's region. Without this
					// the void-grower ambient adoption never fired for enum-wrapped inserts and the
					// payload backing was freed on return (silent UAF).
					for _, arg := range n.Args {
						if rec(arg, depth+1) {
							return true
						}
					}
					return false
				}
				// Otherwise resolve the callee's RETURN TYPE (region-carrying ⇒ region-valued).
				if cn, _, isCall := ast.PrepassCallShape(n); isCall {
					if callee, ok := funcByName[cn]; ok && callee != nil && callee.ReturnType != nil {
						return a.typeIsRegionValued(resolveCalleeReturnType(callee))
					}
				}
				return false
			case *ast.StructLitExpr:
				// Pre-analysis `Name(args)` parses as a StructLitExpr; resolve it as a call.
				if cn, _, isCall := ast.PrepassCallShape(n); isCall {
					if callee, ok := funcByName[cn]; ok && callee != nil && callee.ReturnType != nil {
						return a.typeIsRegionValued(resolveCalleeReturnType(callee))
					}
				}
				// A brace construction `Ty{field: value, …}` carries region storage when any
				// field initializer does (a struct wrapping a packed-enum handle or container —
				// e.g. `items.push(ParamDecl{type_expression: node})`): the wrapper struct is
				// copied into the caller's container but the wrapped handle's record (and its
				// side-table payloads) live in a region, which must therefore be the param's.
				if n != nil && n.Brace {
					for _, fieldValue := range n.Args {
						if rec(fieldValue, depth+1) {
							return true
						}
					}
					for _, spread := range n.Spreads {
						if rec(spread, depth+1) {
							return true
						}
					}
				}
				return false
			}
			return false
		}
		return rec(arg, 0)
	}
	return argIsRegionValued
}

// typeIsRegionValued reports whether a value of this resolved type owns/references region-backed
// storage that must be adopted with it: a container/view/store-struct (typeCarriesRegionStorage), OR
// a region-backed packed-enum HANDLE — whose record lives in a region store and whose variant
// payloads may hold side-table containers (docs/76). The packed-enum case is NOT folded into the
// shared typeCarriesRegionStorage because that predicate gates escape checks with narrower intent;
// here we only decide whether inserting such a value into a caller-owned container forces the
// container's region to be threaded.
func (a *Analyzer) typeIsRegionValued(t Type) bool {
	if typeCarriesRegionStorage(t) {
		return true
	}
	for t != nil {
		switch tt := t.(type) {
		case *OptionalType:
			if tt == nil {
				return false
			}
			t = tt.Value
		case *AggregateStateType:
			if tt == nil {
				return false
			}
			t = tt.Base
		case *RefType:
			if tt == nil {
				return false
			}
			t = tt.Elem
		case *EnumType:
			return tt != nil && (tt.Packed || tt.Root().Packed)
		default:
			return false
		}
	}
	return false
}

// collectProgramLifetimeRoots gathers the names that, when used as an `in <name>:` allocation
// scope, denote program-lifetime (never-freed) storage: the implicit `perm` arena plus every
// global / extern variable (e.g. `global mutable elf_parse_arena: Arena`). A container growth
// lexically inside such a scope needs no threaded caller region — its backing outlives all callers.
func collectProgramLifetimeRoots(decls []scopedDecl) map[string]bool {
	roots := map[string]bool{"perm": true}
	for _, scoped := range decls {
		switch d := scoped.Decl.(type) {
		case *ast.GlobalDecl:
			if d != nil && d.Name != "" {
				roots[d.Name] = true
			}
		case *ast.ExternVarDecl:
			if d != nil && d.Name != "" {
				roots[d.Name] = true
			}
		case *ast.ExportGlobalDecl:
			if d != nil && d.Alias != "" {
				roots[d.Alias] = true
			}
		}
	}
	return roots
}

// storeRegionRootName returns the root identifier name of an `in <store>:` allocation expression,
// peeling `&`, parens, and reborrow casts — so `in &elf_parse_arena:` yields "elf_parse_arena"
// and `in perm:` yields "perm". Returns "" for any shape without a clear root ident.
func storeRegionRootName(store ast.Expr) string {
	for {
		switch e := store.(type) {
		case *ast.ParenExpr:
			store = e.Inner
		case *ast.AddrOfExpr:
			store = e.Operand
		case *ast.CastExpr:
			store = e.Operand
		default:
			if id := rootIdentExpr(store); id != nil {
				return id.Name
			}
			return ""
		}
	}
}

// paramContainerIsGrownNeedingRegion is the region-inference-facing variant of
// paramContainerIsGrown: it reports whether the param's container is grown in a way that REQUIRES
// threading the caller's region — i.e. a growth that is NOT lexically inside a program-lifetime
// `in perm:` / `in &<global>:` scope. A growth whose allocation region is program-lifetime is
// skipped (its backing outlives every caller, so no region param is needed); a growth into a
// scoped/local arena, or with no enclosing region scope, still counts (preserving the prior
// "cannot infer region parameter" / escape behaviour — soundness unchanged). This is the missing
// complement to paramFieldContainerIsGrown's scope-skip, but restricted to PROGRAM-LIFETIME scopes
// so a scoped-arena growth is never silently accepted.
func paramContainerIsGrownNeedingRegion(stmts []ast.Stmt, name string, permRoots map[string]bool) bool {
	found := false
	var rec func(v reflect.Value)
	rec = func(v reflect.Value) {
		if found || !v.IsValid() || !v.CanInterface() {
			return
		}
		switch v.Kind() {
		case reflect.Pointer:
			if v.IsNil() {
				return
			}
			// A growth inside an `in <programLifetimeArena>:` scope already has a program-lifetime
			// allocation region supplied lexically — don't descend (it needs no threaded region).
			if in, ok := v.Interface().(*ast.InStoreStmt); ok && in != nil {
				if permRoots[storeRegionRootName(in.Store)] {
					return
				}
			}
			if call, ok := v.Interface().(*ast.CallExpr); ok {
				if field, ok := call.Func.(*ast.FieldExpr); ok && field != nil && containerGrowthMethods[field.Field] {
					if id, ok := field.Object.(*ast.Ident); ok && id != nil && id.Name == name {
						found = true
						return
					}
				}
			}
			rec(v.Elem())
		case reflect.Interface:
			if v.IsNil() {
				return
			}
			rec(v.Elem())
		case reflect.Struct:
			for i := 0; i < v.NumField(); i++ {
				rec(v.Field(i))
			}
		case reflect.Slice, reflect.Array:
			for i := 0; i < v.Len(); i++ {
				rec(v.Index(i))
			}
		}
	}
	rec(reflect.ValueOf(stmts))
	return found
}

// paramContainerReassignedFromLiteral reports whether the body REASSIGNS the named ref-container
// parameter from a freshly-allocating literal — `param <- [a, b]`, `param <- [x for x in ...]`, or
// `param <- "..."` (the dstr string-literal sugar, still a StringLit at this pre-pass; flow analysis
// later rewrites it to a byte-list literal). Like push, whole-container reassignment from a literal
// allocates a new backing buffer that must land in the param's region — so it equally forces the
// param to be region-polymorphic, allocating into the caller's region (sound) rather than a local
// auto-region (which would dangle through the ref — use-after-free). Only literal RHS forms qualify;
// reassignment from a call/other container raises region-compatibility questions push never had, so
// it is conservatively excluded (a false negative just reinstates the old "active scope" error).
func paramContainerReassignedFromLiteral(stmts []ast.Stmt, name string) bool {
	found := false
	var rec func(v reflect.Value)
	rec = func(v reflect.Value) {
		if found || !v.IsValid() || !v.CanInterface() {
			return
		}
		switch v.Kind() {
		case reflect.Pointer:
			if v.IsNil() {
				return
			}
			if asn, ok := v.Interface().(*ast.AssignStmt); ok && asn != nil && !asn.Optional {
				if id, ok := asn.Target.(*ast.Ident); ok && id != nil && id.Name == name && reassignmentAllocatesFreshBacking(asn.Value) {
					found = true
					return
				}
			}
			rec(v.Elem())
		case reflect.Interface:
			if v.IsNil() {
				return
			}
			rec(v.Elem())
		case reflect.Struct:
			for i := 0; i < v.NumField(); i++ {
				rec(v.Field(i))
			}
		case reflect.Slice, reflect.Array:
			for i := 0; i < v.Len(); i++ {
				rec(v.Index(i))
			}
		}
	}
	rec(reflect.ValueOf(stmts))
	return found
}

// reassignmentAllocatesFreshBacking reports whether an assignment RHS allocates a new container
// backing buffer in place: a list/dict/set literal, a comprehension, or a string literal (the dstr
// sugar, rewritten to a byte-list literal in flow analysis). Parens are unwrapped.
func reassignmentAllocatesFreshBacking(value ast.Expr) bool {
	for {
		paren, ok := value.(*ast.ParenExpr)
		if !ok {
			break
		}
		value = paren.Inner
	}
	switch value.(type) {
	case *ast.ListLitExpr, *ast.ListComprehensionExpr, *ast.StringLit:
		return true
	}
	return false
}
