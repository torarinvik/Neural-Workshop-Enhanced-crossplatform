package main

import (
	"elisacore/src/backend"
	"elisacore/src/semantic"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"strings"
)

// platformLinkFlagsFor returns the link flags for the current host platform from a
// per-target "platforms" map. The host GOOS is normalized to the project.json platform
// keys ("darwin" -> "macos"). Returns nil when no entry matches.
func platformLinkFlagsFor(platforms map[string]projectPlatformOverride) []string {
	if len(platforms) == 0 {
		return nil
	}
	key := runtime.GOOS
	if key == "darwin" {
		key = "macos"
	}
	if override, ok := platforms[key]; ok {
		return override.LinkFlags
	}
	return nil
}

const (
	projectFileName  = "project.json"
	manifestFileName = "manifest.json"
	libraryDirSuffix = ".elisalib"
)

type trustLevel int

const (
	trustNone trustLevel = iota
	trustInclude
	trustFull
)

type projectCommand int

const (
	projectCommandUnknown projectCommand = iota
	projectCommandInit
	projectCommandInitLib
	projectCommandBuild
	projectCommandRun
	projectCommandTest
	projectCommandBench
	projectCommandView
	projectCommandDeps
	projectCommandABILint
	projectCommandEASMLint
)

type projectCLIOptions struct {
	command           projectCommand
	targetName        string
	projectPath       string
	path              string
	output            string
	emitOverride      string
	filter            string
	linkFlags         []string
	trust             trustLevel
	targetTriple      string
	optLevel          backend.OptimizationLevel
	hasOptLevel       bool
	initName          string
	packedProfile     backend.PackedLoweringProfile
	jsonOutput        bool
	strictContracts   bool
	debugInfo         bool
	recordTrace       bool
	strictPolicy      bool
	perfStrict        bool
	flowLintMode      semantic.FlowLintMode
	concurrencyStrict bool
	progressStrict    bool
	proofStrict       bool
	enableSMT         bool
}
type projectDefinition struct {
	Version               string                             `json:"version,omitempty"`
	DependencySearchPaths []string                           `json:"dependency-search-paths,omitempty"`
	Dependencies          []string                           `json:"dependencies,omitempty"`
	IncludeDirs           []string                           `json:"include-dirs,omitempty"`
	Foreign               []string                           `json:"foreign,omitempty"`
	EASM                  []string                           `json:"easm,omitempty"`
	LinkFlags             []string                           `json:"link-flags,omitempty"`
	Exec                  []string                           `json:"exec,omitempty"`
	Targets               map[string]projectTargetDefinition `json:"targets"`
}
type projectTargetDefinition struct {
	Entry                string                 `json:"entry"`
	Emit                 string                 `json:"emit,omitempty"`
	RunEmit              string                 `json:"run-emit,omitempty"`
	Output               string                 `json:"output,omitempty"`
	Dependencies         []string               `json:"dependencies,omitempty"`
	IncludeDirs          []string               `json:"include-dirs,omitempty"`
	Foreign              []string               `json:"foreign,omitempty"`
	EASM                 []string               `json:"easm,omitempty"`
	LinkFlags            []string               `json:"link-flags,omitempty"`
	InheritProjectNative *bool                  `json:"inherit-project-native,omitempty"`
	Exec                 []string               `json:"exec,omitempty"`
	Opt                  string                 `json:"opt,omitempty"`
	TargetTriple         string                 `json:"target-triple,omitempty"`
	PackedABI            string                 `json:"packed-abi,omitempty"`
	Warnings             *projectTargetWarnings `json:"warnings,omitempty"`
	Platforms            map[string]projectPlatformOverride `json:"platforms,omitempty"`
}

// projectPlatformOverride carries host-platform-specific build settings selected at
// resolve time by the host GOOS (e.g. "macos"/"linux"/"windows"). Only the matching
// platform's settings are applied; others are ignored.
type projectPlatformOverride struct {
	LinkFlags []string `json:"link-flags,omitempty"`
}
type projectTargetWarnings struct {
	Strict      bool `json:"strict,omitempty"`
	Perf        bool `json:"perf,omitempty"`
	Concurrency bool `json:"concurrency,omitempty"`
	Progress    bool `json:"progress,omitempty"`
}
type manifestDefinition struct {
	Provides     string   `json:"provides"`
	Entry        string   `json:"entry,omitempty"`
	Interface    string   `json:"interface,omitempty"`
	Dependencies []string `json:"dependencies,omitempty"`
	IncludeDirs  []string `json:"include-dirs,omitempty"`
	Foreign      []string `json:"foreign,omitempty"`
	EASM         []string `json:"easm,omitempty"`
	LinkFlags    []string `json:"link-flags,omitempty"`
	Exec         []string `json:"exec,omitempty"`
}
type resolvedProject struct {
	root     string
	filePath string
	config   projectDefinition
}
type resolvedManifest struct {
	name          string
	dir           string
	manifestPath  string
	entryPath     string
	interfacePath string
	includeDirs   []string
	foreignFiles  []string
	easmFiles     []string
	linkFlags     []string
	dependencies  []*resolvedManifest
	exec          []string
}
type resolvedProjectTarget struct {
	project               *resolvedProject
	name                  string
	entryPath             string
	emit                  string
	runEmit               string
	outputPath            string
	includeDirs           []string
	dependencySearchPaths []string
	dependencyOrder       []*resolvedManifest
	foreignFiles          []string
	easmFiles             []string
	linkFlags             []string
	projectExec           []string
	targetExec            []string
	optLevel              backend.OptimizationLevel
	hasOptLevel           bool
	targetTriple          string
	packedProfile         backend.PackedLoweringProfile
	strictPolicy          bool
	perfStrict            bool
	flowLintMode          semantic.FlowLintMode
	concurrencyStrict     bool
	progressStrict        bool
	proofStrict           bool
	enableSMT             bool
}
type projectResolver struct {
	searchPaths []string
	cache       map[string]*resolvedManifest
	resolving   map[string]bool
}
type sourceExpandOptions struct {
	includeDirs []string
}

func isProjectCommand(name string) bool {
	switch strings.TrimSpace(name) {
	case "init", "init-lib", "build", "run", "test", "bench", "project":
		return true
	default:
		return false
	}
}
func runProjectCLI(args []string, stdout io.Writer, stderr io.Writer) int {
	options, err := parseProjectCLIArgs(args)
	if err != nil {
		fmt.Fprintf(stderr, "error: %s\n", err)
		printProjectUsage(stderr)
		return 1
	}

	switch options.command {
	case projectCommandInit:
		if err := scaffoldProject(options); err != nil {
			fmt.Fprintf(stderr, "error: %s\n", err)
			return 1
		}
		return 0
	case projectCommandInitLib:
		if err := scaffoldLibrary(options); err != nil {
			fmt.Fprintf(stderr, "error: %s\n", err)
			return 1
		}
		return 0
	}

	project, err := loadResolvedProject(options.projectPath)
	if err != nil {
		fmt.Fprintf(stderr, "error: %s\n", err)
		return 1
	}
	if options.command == projectCommandView {
		return runProjectView(project, options, stdout, stderr)
	}
	if options.command == projectCommandDeps {
		return runProjectDeps(project, options, stdout, stderr)
	}
	if options.command == projectCommandABILint {
		return runProjectABILint(project, options, stdout, stderr)
	}
	if options.command == projectCommandEASMLint {
		return runProjectEASMLint(project, options, stdout, stderr)
	}

	target, err := resolveProjectTarget(project, options)
	if err != nil {
		fmt.Fprintf(stderr, "error: %s\n", err)
		return 1
	}
	if err := runResolvedProjectHooks(target, options.trust, stderr); err != nil {
		fmt.Fprintf(stderr, "error: %s\n", err)
		return 1
	}
	program, err := buildProjectLoadedProgram(target)
	if err != nil {
		fmt.Fprintf(stderr, "error: %s\n", err)
		return 1
	}

	cli := cliOptions{
		emit:              target.emit,
		filename:          target.entryPath,
		output:            target.outputPath,
		filter:            options.filter,
		foreignFiles:      append([]string(nil), target.foreignFiles...),
		linkFlags:         append([]string(nil), target.linkFlags...),
		targetTriple:      target.targetTriple,
		packedProfile:     target.packedProfile,
		hasOptLevel:       target.hasOptLevel,
		optLevel:          target.optLevel,
		debugInfo:         options.debugInfo,
		recordTrace:       options.recordTrace,
		strictPolicy:      target.strictPolicy,
		perfStrict:        target.perfStrict,
		flowLintMode:      target.flowLintMode,
		concurrencyStrict: target.concurrencyStrict,
		progressStrict:    target.progressStrict,
		proofStrict:       target.proofStrict,
		enableSMT:         target.enableSMT,
	}

	switch options.command {
	case projectCommandRun:
		cli.emit = target.runEmit
		cli.output = ""
		if cli.emit == emitObject {
			cli.runNative = true
		}
	case projectCommandTest:
		cli.emit = emitTest
		cli.output = ""
	case projectCommandBench:
		cli.emit = emitBenches
		cli.output = ""
	case projectCommandBuild:
		if cli.emit == emitObject && shouldLinkNativeProjectBuild(cli.output) {
			cli.linkNative = true
		}
	default:
		fmt.Fprintf(stderr, "error: unsupported project command\n")
		return 1
	}
	return runLoadedProgramWithOptions(cli, program, stdout, stderr)
}
func shouldLinkNativeProjectBuild(outputPath string) bool {
	trimmed := strings.TrimSpace(outputPath)
	if trimmed == "" {
		return false
	}
	return strings.ToLower(filepath.Ext(trimmed)) != ".o"
}
func parseProjectCLIArgs(args []string) (projectCLIOptions, error) {
	if len(args) == 0 {
		return projectCLIOptions{}, fmt.Errorf("missing project command")
	}
	// docs/90: SMT discharge tier ON by default (see the main CLI note); `-nosmt` opts out.
	// docs/85: prove-it-or-fail (`-strict`) is also the default; `-permissive` opts out.
	options := projectCLIOptions{trust: trustNone, enableSMT: true, proofStrict: true, packedProfile: backend.DefaultPackedLoweringProfile()}
	switch args[0] {
	case "init":
		options.command = projectCommandInit
	case "init-lib":
		options.command = projectCommandInitLib
	case "build":
		options.command = projectCommandBuild
	case "run":
		options.command = projectCommandRun
	case "test":
		options.command = projectCommandTest
	case "bench":
		options.command = projectCommandBench
	case "project":
		if len(args) < 2 {
			return projectCLIOptions{}, fmt.Errorf("missing project subcommand")
		}
		subcommand := strings.TrimSpace(args[1])
		if subcommand != "view" && subcommand != "deps" && subcommand != "abi-lint" && subcommand != "easm-lint" {
			return projectCLIOptions{}, fmt.Errorf("unsupported project subcommand %q", subcommand)
		}
		if subcommand == "view" {
			options.command = projectCommandView
		} else if subcommand == "deps" {
			options.command = projectCommandDeps
		} else if subcommand == "abi-lint" {
			options.command = projectCommandABILint
		} else {
			options.command = projectCommandEASMLint
		}
		args = append([]string{args[0]}, args[2:]...)
	default:
		return projectCLIOptions{}, fmt.Errorf("unsupported project command %q", args[0])
	}

	start := 1
	if options.command == projectCommandView {
		start = 1
	}
	for i := start; i < len(args); i++ {
		arg := args[i]
		switch {
		case arg == "":
			continue
		case strings.HasPrefix(arg, "--project="):
			options.projectPath = strings.TrimSpace(strings.TrimPrefix(arg, "--project="))
		case arg == "--project" || arg == "-p":
			i++
			if i >= len(args) {
				return projectCLIOptions{}, fmt.Errorf("missing value after %s", arg)
			}
			options.projectPath = strings.TrimSpace(args[i])
		case strings.HasPrefix(arg, "--path="):
			options.path = strings.TrimSpace(strings.TrimPrefix(arg, "--path="))
		case arg == "--path":
			i++
			if i >= len(args) {
				return projectCLIOptions{}, fmt.Errorf("missing value after --path")
			}
			options.path = strings.TrimSpace(args[i])
		case arg == "--strict":
			if options.command != projectCommandInit {
				return projectCLIOptions{}, fmt.Errorf("--strict is only supported by init; use -Wstrict for build, run, test, and bench")
			}
			options.strictPolicy = true
		case strings.HasPrefix(arg, "--trust="):
			trust, err := parseTrustLevel(strings.TrimSpace(strings.TrimPrefix(arg, "--trust=")))
			if err != nil {
				return projectCLIOptions{}, err
			}
			options.trust = trust
		case arg == "--trust":
			i++
			if i >= len(args) {
				return projectCLIOptions{}, fmt.Errorf("missing value after --trust")
			}
			trust, err := parseTrustLevel(strings.TrimSpace(args[i]))
			if err != nil {
				return projectCLIOptions{}, err
			}
			options.trust = trust
		case strings.HasPrefix(arg, "-filter="):
			options.filter = strings.TrimSpace(strings.TrimPrefix(arg, "-filter="))
		case arg == "-filter":
			i++
			if i >= len(args) {
				return projectCLIOptions{}, fmt.Errorf("missing value after -filter")
			}
			options.filter = strings.TrimSpace(args[i])
		case strings.HasPrefix(arg, "-target-triple="):
			options.targetTriple = strings.TrimSpace(strings.TrimPrefix(arg, "-target-triple="))
		case arg == "-target-triple":
			i++
			if i >= len(args) {
				return projectCLIOptions{}, fmt.Errorf("missing value after -target-triple")
			}
			options.targetTriple = strings.TrimSpace(args[i])
		case strings.HasPrefix(arg, "-emit="):
			options.emitOverride = normalizeEmitMode(strings.TrimSpace(strings.TrimPrefix(arg, "-emit=")))
		case arg == "-emit":
			i++
			if i >= len(args) {
				return projectCLIOptions{}, fmt.Errorf("missing value after -emit")
			}
			options.emitOverride = normalizeEmitMode(strings.TrimSpace(args[i]))
		case arg == "-O0" || arg == "-O2" || arg == "-O3":
			level, err := parseOptimizationArg(strings.TrimPrefix(arg, "-O"))
			if err != nil {
				return projectCLIOptions{}, err
			}
			options.optLevel = level
			options.hasOptLevel = true
		case strings.HasPrefix(arg, "-o="):
			options.output = strings.TrimSpace(strings.TrimPrefix(arg, "-o="))
		case arg == "--json":
			options.jsonOutput = true
		case arg == "--strict-contracts":
			options.strictContracts = true
		case arg == "-g" || arg == "-debug-info":
			options.debugInfo = true
		case arg == "-ftrace" || arg == "-record-trace":
			options.recordTrace = true
		case arg == "-fbounds-check":
			// Force the debug index-bounds watchdog on regardless of optimization level.
			// The watchdog gate reads this env var at codegen time (build is in-process).
			_ = os.Setenv("ELISACORE_FORCE_BOUNDS_CHECK", "1")
		case arg == "-ffast-math":
			// Opt the whole program into full fast-math FP (reassociation etc.), unlocking the
			// reassociated tree reduction for FP folds. Read at codegen time (in-process build).
			_ = os.Setenv("ELISACORE_FAST_MATH", "1")
		case arg == "-fnoalias":
			// Stamp LLVM `noalias` only on the eligible numeric-scalar `mutable T&` subset.
			// Mutable darray references are forwarded through nested calls and are deliberately
			// excluded. Keep the opt-in OFF by default because a noalias miscompile is silent.
			// Read at codegen time, same env the backend generator consults.
			_ = os.Setenv("ELISACORE_NOALIAS_MUTABLE_REFS", "1")
		case arg == "-Wperf":
			options.perfStrict = true
		case arg == "-Wflow":
			// docs/121: flow-checked-loop lints, warn tier (Phase A). See the single-file CLI parser
			// for the full note. The declarative `[warnings] flow` manifest field lands in Phase C.
			options.flowLintMode = semantic.FlowLintWarn
		case arg == "-Wflow-strict":
			options.flowLintMode = semantic.FlowLintStrict
		case arg == "-Wconcurrency":
			options.concurrencyStrict = true
		case arg == "-Wprogress":
			// docs/102: activate the (already-built but dormant) progress-safety obligation
			// checker on its own dial — every `while` loop / recursive cycle must show progress
			// evidence (`decreases`, `Progress.*`) or declare intentional non-progress.
			options.progressStrict = true
		case arg == "-smt":
			// docs/90: SMT discharge tier — ON by default; explicit opt-in kept for back-compat.
			options.enableSMT = true
		case arg == "-nosmt":
			// Opt out of the default-on SMT discharge tier.
			options.enableSMT = false
		case arg == "-strict":
			// docs/85: prove-it-or-fail — an obligation that cannot be discharged statically
			// fails the build. ON by default now; explicit opt-in / harmless no-op for back-compat.
			options.proofStrict = true
		case arg == "-permissive":
			// Opt out of default-on strict proofs: an unprovable refinement/contract degrades to
			// a warning + debug runtime check instead of failing the build.
			options.proofStrict = false
		case arg == "-Wstrict":
			options.strictPolicy = true
			options.perfStrict = true
			options.concurrencyStrict = true
			options.progressStrict = true
			options.proofStrict = true
		case arg == "-o":
			i++
			if i >= len(args) {
				return projectCLIOptions{}, fmt.Errorf("missing value after -o")
			}
			options.output = strings.TrimSpace(args[i])
		case strings.HasPrefix(arg, "-link="):
			value := strings.TrimSpace(strings.TrimPrefix(arg, "-link="))
			if value == "" {
				return projectCLIOptions{}, fmt.Errorf("missing value after -link")
			}
			options.linkFlags = append(options.linkFlags, value)
		case arg == "-link":
			i++
			if i >= len(args) {
				return projectCLIOptions{}, fmt.Errorf("missing value after -link")
			}
			value := strings.TrimSpace(args[i])
			if value == "" {
				return projectCLIOptions{}, fmt.Errorf("missing value after -link")
			}
			options.linkFlags = append(options.linkFlags, value)
		case strings.HasPrefix(arg, "-L="):
			value := strings.TrimSpace(strings.TrimPrefix(arg, "-L="))
			if value == "" {
				return projectCLIOptions{}, fmt.Errorf("missing value after -L")
			}
			options.linkFlags = append(options.linkFlags, "-L"+value)
		case arg == "-L":
			i++
			if i >= len(args) {
				return projectCLIOptions{}, fmt.Errorf("missing value after -L")
			}
			value := strings.TrimSpace(args[i])
			if value == "" {
				return projectCLIOptions{}, fmt.Errorf("missing value after -L")
			}
			options.linkFlags = append(options.linkFlags, "-L"+value)
		case strings.HasPrefix(arg, "-l") && len(arg) > len("-l"):
			options.linkFlags = append(options.linkFlags, arg)
		case arg == "-l":
			i++
			if i >= len(args) {
				return projectCLIOptions{}, fmt.Errorf("missing value after -l")
			}
			value := strings.TrimSpace(args[i])
			if value == "" {
				return projectCLIOptions{}, fmt.Errorf("missing value after -l")
			}
			options.linkFlags = append(options.linkFlags, "-l"+value)
		case arg == "-h" || arg == "--help":
			return projectCLIOptions{}, fmt.Errorf("help requested")
		case strings.HasPrefix(arg, "-"):
			return projectCLIOptions{}, fmt.Errorf("unknown option %q", arg)
		default:
			switch options.command {
			case projectCommandInit, projectCommandInitLib:
				if options.initName != "" {
					return projectCLIOptions{}, fmt.Errorf("expected a single project or library name, got %q", arg)
				}
				options.initName = arg
			case projectCommandBuild, projectCommandRun, projectCommandTest, projectCommandBench, projectCommandView, projectCommandDeps, projectCommandABILint, projectCommandEASMLint:
				if options.targetName != "" {
					return projectCLIOptions{}, fmt.Errorf("expected a single target name, got %q", arg)
				}
				options.targetName = arg
			default:
				return projectCLIOptions{}, fmt.Errorf("unexpected argument %q", arg)
			}
		}
	}

	switch options.command {
	case projectCommandInit, projectCommandInitLib:
		if strings.TrimSpace(options.initName) == "" {
			return projectCLIOptions{}, fmt.Errorf("missing project or library name")
		}
	}
	return options, nil
}
func parseTrustLevel(value string) (trustLevel, error) {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "none", "":
		return trustNone, nil
	case "include":
		return trustInclude, nil
	case "full":
		return trustFull, nil
	default:
		return trustNone, fmt.Errorf("unsupported trust level %q (expected none, include, or full)", value)
	}
}
func printProjectUsage(w io.Writer) {
	fmt.Fprintln(w, "Project commands:")
	fmt.Fprintln(w, "  elisacore init <name> [--path <dir>] [--strict]")
	fmt.Fprintln(w, "  elisacore init-lib <name> [--path <dir>]")
	fmt.Fprintln(w, "  elisacore build [target] [--project <dir|project.json>] [-emit <mode>] [-o <output>] [-link <flag>|-L <dir>|-l <name>] [--trust <none|include|full>] [-O0|-O2|-O3]")
	fmt.Fprintln(w, "  elisacore run [target] [--project <dir|project.json>] [-link <flag>|-L <dir>|-l <name>] [--trust <none|include|full>]")
	fmt.Fprintln(w, "  elisacore test [target] [--project <dir|project.json>] [-filter <substring>] [-link <flag>|-L <dir>|-l <name>] [--trust <none|include|full>] [-O0|-O2|-O3]")
	fmt.Fprintln(w, "  elisacore bench [target] [--project <dir|project.json>] [-filter <substring>] [--trust <none|include|full>]")
	fmt.Fprintln(w, "  elisacore project view [target] [--project <dir|project.json>]")
	fmt.Fprintln(w, "  elisacore project deps [target] [--project <dir|project.json>] [--json]")
	fmt.Fprintln(w, "  elisacore project abi-lint [target] [--project <dir|project.json>] [--json] [--strict-contracts]")
	fmt.Fprintln(w, "  elisacore project easm-lint [target] [--project <dir|project.json>] [--json]")
}
func scaffoldProject(options projectCLIOptions) error {
	basePath := options.path
	if strings.TrimSpace(basePath) == "" {
		cwd, err := os.Getwd()
		if err != nil {
			return err
		}
		basePath = cwd
	}
	root := filepath.Join(basePath, options.initName)
	if _, err := os.Stat(root); err == nil {
		return fmt.Errorf("path %s already exists", root)
	} else if !os.IsNotExist(err) {
		return err
	}
	if err := os.MkdirAll(filepath.Join(root, "src"), 0o755); err != nil {
		return err
	}
	for _, dir := range []string{"build", "lib", "native", "test"} {
		if err := os.MkdirAll(filepath.Join(root, dir), 0o755); err != nil {
			return err
		}
	}
	project := projectDefinition{
		Version:               "0.1.0",
		DependencySearchPaths: []string{"lib"},
		Dependencies:          []string{},
		IncludeDirs:           []string{"src"},
		Foreign:               []string{},
		Exec:                  []string{},
		Targets: map[string]projectTargetDefinition{
			"app": {
				Entry:        "src/main.elisa",
				Emit:         emitLLVM,
				RunEmit:      emitInterpret,
				Output:       filepath.ToSlash(filepath.Join("build", "app.ll")),
				Dependencies: []string{},
				IncludeDirs:  []string{},
				Foreign:      []string{},
				Exec:         []string{},
				Opt:          "O0",
			},
		},
	}
	if options.strictPolicy {
		target := project.Targets["app"]
		target.Warnings = &projectTargetWarnings{Strict: true}
		project.Targets["app"] = target
	}
	projectData, err := json.MarshalIndent(project, "", "  ")
	if err != nil {
		return err
	}
	if err := writeOutputFile(filepath.Join(root, projectFileName), append(projectData, '\n')); err != nil {
		return err
	}
	mainSource := "def main() -> int:\n    return 0\n"
	if err := writeOutputFile(filepath.Join(root, "src", "main.elisa"), []byte(mainSource)); err != nil {
		return err
	}
	for _, placeholder := range []string{filepath.Join(root, "lib", ".gitkeep"), filepath.Join(root, "test", ".gitkeep")} {
		if err := writeOutputFile(placeholder, nil); err != nil {
			return err
		}
	}
	return nil
}
func scaffoldLibrary(options projectCLIOptions) error {
	basePath := options.path
	if strings.TrimSpace(basePath) == "" {
		cwd, err := os.Getwd()
		if err != nil {
			return err
		}
		basePath = cwd
	}
	root := filepath.Join(basePath, options.initName+libraryDirSuffix)
	if _, err := os.Stat(root); err == nil {
		return fmt.Errorf("path %s already exists", root)
	} else if !os.IsNotExist(err) {
		return err
	}
	if err := os.MkdirAll(filepath.Join(root, "src"), 0o755); err != nil {
		return err
	}
	manifest := manifestDefinition{
		Provides:     options.initName,
		Entry:        filepath.ToSlash(filepath.Join("src", options.initName+".elisa")),
		Interface:    filepath.ToSlash(filepath.Join("src", options.initName+interfaceExtension)),
		Dependencies: []string{},
		IncludeDirs:  []string{"src"},
		Foreign:      []string{},
		Exec:         []string{},
	}
	manifestData, err := json.MarshalIndent(manifest, "", "  ")
	if err != nil {
		return err
	}
	if err := writeOutputFile(filepath.Join(root, manifestFileName), append(manifestData, '\n')); err != nil {
		return err
	}
	libFunc := sanitizeIdentifier(options.initName) + "_value"
	libSource := fmt.Sprintf("def %s() -> int:\n    return 1\n", libFunc)
	if err := writeOutputFile(filepath.Join(root, "src", options.initName+".elisa"), []byte(libSource)); err != nil {
		return err
	}
	ifaceSource := fmt.Sprintf("extern %s() -> int\n", libFunc)
	if err := writeOutputFile(filepath.Join(root, "src", options.initName+interfaceExtension), []byte(ifaceSource)); err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Join(root, "native"), 0o755); err != nil {
		return err
	}
	if err := writeOutputFile(filepath.Join(root, "README.md"), []byte(fmt.Sprintf("# %s\n", options.initName))); err != nil {
		return err
	}
	return nil
}
func sanitizeIdentifier(name string) string {
	trimmed := strings.TrimSpace(name)
	if trimmed == "" {
		return "project"
	}
	var b strings.Builder
	for _, r := range trimmed {
		switch {
		case r >= 'a' && r <= 'z':
			b.WriteRune(r)
		case r >= 'A' && r <= 'Z':
			b.WriteRune(r + ('a' - 'A'))
		case r >= '0' && r <= '9':
			if b.Len() == 0 {
				b.WriteString("p_")
			}
			b.WriteRune(r)
		default:
			if b.Len() == 0 || strings.HasSuffix(b.String(), "_") {
				continue
			}
			b.WriteRune('_')
		}
	}
	result := strings.Trim(b.String(), "_")
	if result == "" {
		return "project"
	}
	return result
}
func loadResolvedProject(path string) (*resolvedProject, error) {
	projectPath, err := findProjectFile(path)
	if err != nil {
		return nil, err
	}
	var definition projectDefinition
	if err := decodeJSONFile(projectPath, &definition); err != nil {
		return nil, err
	}
	if len(definition.Targets) == 0 {
		return nil, fmt.Errorf("%s does not define any targets", projectPath)
	}
	root := filepath.Dir(projectPath)
	return &resolvedProject{root: root, filePath: projectPath, config: definition}, nil
}
